# site para enviar impulsos automático

que funcione

## Como usar
1. Coloque os 4 arquivos na mesma pasta.
2. Abra o `index.html` no navegador.
3. Edite `style.css` (variáveis no topo) pra mudar cores e fontes.
4. Edite `script.js` pra ajustar comportamentos (formulário, contadores, etc.).

## Arquivos
- `index.html` — estrutura completa (nav, hero, sobre, recursos, números, depoimentos, FAQ, contato, footer)
- `style.css`  — design responsivo, dark/light, animações
- `script.js`  — tema, menu mobile, scroll reveal, contadores, validação de form
- `README.md`  — este arquivo

## Referência
N/A
