function enviarImpulsosAutomatico() {
  const intervalo = 1000; // 1 segundo
  const quantidadeImpulsos = 10;
  let contador = 0;

  function enviarImpulso() {
    console.log("Enviando impulso...");
    // Aqui você pode colocar o código para enviar o impulso
    // Exemplo: fetch("https://example.com/enviar-impulso")
    contador++;
    if (contador < quantidadeImpulsos) {
      setTimeout(enviarImpulso, intervalo);
    }
  }

  enviarImpulso();
}

enviarImpulsosAutomatico();